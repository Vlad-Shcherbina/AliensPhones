n = 340333
m = 1500

with open("Sambuca", 'w') as fout:
    for i in range(333, 340):
        print>>fout, i
    for i in range(n, n+m):
        print>>fout, i